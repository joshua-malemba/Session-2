
message = "hello there guys"
message.upper

print(message.split())


# print out the position of Liam 


Player_list = ['Amy', 'Justin', 'Liam']
print(Player_list[0])
print(Player_list[1:])
print(Player_list[-1])
print(Player_list[0].upper())
print(Player_list[0].upper() + ' IS THE WINNER')

Player_list.count('J')
Player_list.index('L')
Player_List.remove('K')
Player_list.reverse()
Player.sort()

database = ['Liam', 'Joshua', 'Brittany']

username = input("What is your name ? : ")

if username in database:
    print("login successful!")
else:
    print("login unsuccessful!")



if 3 > 2:
    print('3 is bigger than 2')
elif 3 < 2: 
    print('2 is bigger than 3')
if 1 == 1: 
    Print('1 is equal to 1')
elif 1 != 1: 
    Print('1 is not equal to 1')

player_list = ['Liam', 'Joshua', 'Brittany']


