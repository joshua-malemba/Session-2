TeamYouSupport= input("Which team do you support?: ")
if TeamYouSupport == 'Man Utd':
    print('DEADDDDDDD')
else:
    'hmmmm not so bad'
